#!/system/bin/sh

# Wait for boot to complete
while [ -z "$(getprop sys.boot_completed)" ]; do
    sleep 1
done

# Stop thermal services and freeze processes
thermal() {
    find /system/etc/init /vendor/etc/init /odm/etc/init -type f 2>/dev/null | xargs grep -h "^service" | awk '{print $2}' | grep thermal
}

for svc in $(thermal) android.hardware.thermal-service.mediatek android.hardware.thermal@2.0-service.mtk thermal thermald thermal_core thermal_manager vendor.thermal-hal-2-0.mtk mi_thermald vendor.thermal-engine vendor.thermal-manager vendor.thermal-hal-2-0 vendor.thermal-symlinks vendor.thermal.link_ready vendor.thermal.symlinks thermal_mnt_hal_service vendor.thermal-hal thermalloadalgod thermalservice sec-thermal-1-0 debug_pid.sec-thermal-1-0 thermal-engine vendor.thermal-hal-1-0 android.thermal-hal vendor-thermal-1-0 thermal-hal android.thermal-hal; do
    stop "$svc"
    pid=$(pidof "$svc")
    if [ -n "$pid" ]; then
        kill -SIGSTOP "$pid"
    fi
done

# Clear init.svc_ properties
for prop in $(getprop | awk -F '[][]' '/init\.svc_/ {print $2}'); do
    if [ -n "$prop" ]; then
        resetprop -n "$prop" ""
    fi
done

# Set init.svc properties to stopped and clear
for prop in $(getprop | grep thermal | cut -f1 -d] | cut -f2 -d[ | grep -F init.svc.); do
    setprop "$prop" stopped
    setprop "$prop" ""
done

# Disable thermal zones
chmod 644 /sys/class/thermal/thermal_zone*/mode
for zone in /sys/class/thermal/thermal_zone*/mode; do
    [ -f "$zone" ] && echo "disabled" > "$zone"
done

for zone2 in /sys/class/thermal/thermal_zone*/policy; do
    [ -f "$zone2" ] && echo "userspace" > "$zone2"
done

# Set high trip points for specific zones
for zone in thermal_zone0 thermal_zone9 thermal_zone10; do
    echo 999999999 > /sys/class/thermal/$zone/trip_point_0_temp
done

# Disable GPU Power Limitations
if [ -f "/proc/gpufreq/gpufreq_power_limited" ]; then
    for setting in ignore_batt_oc ignore_batt_percent ignore_low_batt ignore_thermal_protect ignore_pbm_limited; do
        echo "$setting 1" > /proc/gpufreq/gpufreq_power_limited
    done
fi

# Set CPU limits based on max frequency
if [ -f /sys/devices/virtual/thermal/thermal_message/cpu_limits ]; then
    for cpu in 0 2 4 6 7; do
        maxfreq_path="/sys/devices/system/cpu/cpu$cpu/cpufreq/cpuinfo_max_freq"
        if [ -f "$maxfreq_path" ]; then
            maxfreq=$(cat "$maxfreq_path")
            [ -n "$maxfreq" ] && [ "$maxfreq" -gt 0 ] && echo "cpu$cpu $maxfreq" > /sys/devices/virtual/thermal/thermal_message/cpu_limits
        fi
    done
fi

# Disable PPM (Power Policy Manager) Limits
if [ -d /proc/ppm ] && [ -f /proc/ppm/policy_status ]; then
    for idx in $(grep -E 'FORCE_LIMIT|PWR_THRO|THERMAL' /proc/ppm/policy_status | awk -F'[][]' '{print $2}'); do
        echo "$idx 0" > /proc/ppm/policy_status
    done
fi

# Hide and disable monitoring of thermal zones
find /sys/devices/virtual/thermal -type f -exec chmod 000 {} +

# Disable Thermal Stats
cmd thermalservice override-status 0

# Disable Battery Overcharge Thermal Throttling
if [ -f "/proc/mtk_batoc_throttling/battery_oc_protect_stop" ]; then
    echo "stop 1" > /proc/mtk_batoc_throttling/battery_oc_protect_stop
fi

# Disable workqueue power efficiency and NUMA
echo "N" > /sys/module/workqueue/parameters/power_efficient
echo "N" > /sys/module/workqueue/parameters/disable_numa

